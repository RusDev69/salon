import type { Metadata } from "next";
import "@fontsource/playfair-display/400.css";
import "@fontsource/playfair-display/400-italic.css";
import "@fontsource/playfair-display/500.css";
import "@fontsource/playfair-display/600.css";
import "@fontsource/inter/300.css";
import "@fontsource/inter/400.css";
import "@fontsource/inter/500.css";
import "@fontsource/inter/600.css";
import "@fontsource/inter/700.css";
import "./globals.css";
import { Providers } from "@/components/providers";
import { Toaster } from "sonner";

export const metadata: Metadata = {
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",
  ),
  title: {
    default: "ÉCLAT — Beauty Atelier в Москве",
    template: "%s · ÉCLAT",
  },
  description:
    "Камерный салон красоты на Пречистенке: авторское окрашивание, уход за кожей, маникюр и макияж. Онлайн-запись за 2 минуты.",
  keywords: [
    "салон красоты Москва",
    "окрашивание волос",
    "маникюр",
    "косметология",
    "Пречистенка",
  ],
  openGraph: {
    title: "ÉCLAT — Beauty Atelier",
    description:
      "Пространство, где красота становится тишиной. Онлайн-запись в салон на Пречистенке.",
    type: "website",
    locale: "ru_RU",
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ru">
      <body>
        {/* Content stays visible if JavaScript is unavailable or fails. */}
        <noscript>
          <style>{`[data-reveal]{opacity:1!important;transform:none!important}`}</style>
        </noscript>
        <Providers>
          {children}
          <Toaster
            position="top-center"
            offset={92}
            toastOptions={{
              style: {
                background: "#FDFBF7",
                border: "1px solid #E8DCCD",
                color: "#2C2521",
                borderRadius: "16px",
                boxShadow: "0 24px 60px -30px rgba(70,48,40,.4)",
              },
            }}
          />
        </Providers>
      </body>
    </html>
  );
}
