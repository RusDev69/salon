import Link from "next/link";
import { cn } from "@/lib/utils";

export function Logo({
  className,
  tone = "dark",
  compact = false,
}: {
  className?: string;
  tone?: "dark" | "light";
  compact?: boolean;
}) {
  return (
    <Link
      href="/"
      aria-label="ÉCLAT — на главную"
      className={cn("group inline-flex flex-col leading-none", className)}
    >
      <span
        className={cn(
          "font-display text-[27px] tracking-[0.18em] transition-colors",
          tone === "light" ? "text-cream" : "text-espresso",
        )}
      >
        ÉCLAT
        <span className="ml-1 inline-block h-1.5 w-1.5 rounded-full bg-gold-500 align-top" />
      </span>
      {!compact && (
        <span
          className={cn(
            "mt-1.5 pl-0.5 text-[7.5px] font-semibold uppercase tracking-[0.48em]",
            tone === "light" ? "text-cream/50" : "text-espresso/45",
          )}
        >
          Beauty Atelier
        </span>
      )}
    </Link>
  );
}
