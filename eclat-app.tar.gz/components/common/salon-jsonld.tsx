import { BRAND } from "@/lib/constants";

/**
 * BeautySalon structured data helps search engines show the address, phone
 * and rating for branded queries. Values are static and controlled by us, so
 * serialising them into a script tag is safe.
 */
export function SalonJsonLd() {
  const data = {
    "@context": "https://schema.org",
    "@type": "BeautySalon",
    "@id": `${process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"}/#salon`,
    name: BRAND.fullName,
    description:
      "Камерный салон красоты на Пречистенке: авторское окрашивание, уход за кожей, маникюр и макияж.",
    telephone: BRAND.phone,
    email: BRAND.email,
    priceRange: "₽₽₽",
    address: {
      "@type": "PostalAddress",
      streetAddress: "Пречистенка, 12",
      addressLocality: "Москва",
      addressCountry: "RU",
    },
    openingHoursSpecification: [
      {
        "@type": "OpeningHoursSpecification",
        dayOfWeek: [
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday",
          "Sunday",
        ],
        opens: "10:00",
        closes: "21:00",
      },
    ],
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: "4.9",
      reviewCount: "405",
      bestRating: "5",
    },
    sameAs: [BRAND.instagram, BRAND.telegram],
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}
