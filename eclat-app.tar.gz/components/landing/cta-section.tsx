import Link from "next/link";
import { ArrowUpRight, Gift } from "lucide-react";
import { Reveal } from "@/components/common/reveal";
import { Button } from "@/components/ui/button";

export function CtaSection() {
  return (
    <section className="relative overflow-hidden bg-cream py-16 lg:py-20">
      <div className="container-wide">
        <Reveal>
          <div className="noise relative overflow-hidden rounded-[36px] bg-gradient-to-br from-[#B97576] via-[#A96669] to-[#7E484D] px-6 py-14 text-cream shadow-[0_40px_90px_-45px_rgba(126,72,77,.65)] sm:px-12 lg:px-16 lg:py-20">
            <div className="pointer-events-none absolute -right-20 -top-32 h-[420px] w-[420px] rounded-full border border-cream/10" />
            <div className="pointer-events-none absolute -right-6 -top-16 h-[300px] w-[300px] rounded-full border border-gold-300/20" />
            <div className="pointer-events-none absolute bottom-0 left-1/2 h-56 w-56 -translate-x-1/2 rounded-t-full border border-cream/10" />

            <div className="relative grid gap-10 lg:grid-cols-[1.15fr_0.85fr] lg:items-end">
              <div>
                <p className="flex items-center gap-3 text-[9px] font-semibold uppercase tracking-[0.3em] text-gold-200">
                  <span className="h-px w-8 bg-gold-300/70" />
                  Подарите себе паузу
                </p>
                <h2 className="mt-6 max-w-2xl text-balance font-display text-[clamp(2.8rem,6vw,5.4rem)] font-normal leading-[0.96] tracking-[-0.035em]">
                  Час тишины,
                  <br />
                  <span className="italic text-[#F3D9CE]">который меняет всё</span>
                </h2>
              </div>

              <div className="lg:pb-2">
                <p className="max-w-sm text-pretty text-[13px] leading-7 text-cream/70">
                  Выберите ритуал, мастера и удобное время. Онлайн-запись занимает
                  две минуты, а впечатление остаётся надолго.
                </p>
                <div className="mt-6 flex flex-wrap gap-3">
                  <Button asChild size="lg" className="bg-cream text-espresso hover:bg-white">
                    <Link href="/booking">
                      Записаться онлайн
                      <ArrowUpRight className="h-4 w-4" />
                    </Link>
                  </Button>
                  <Button
                    asChild
                    size="lg"
                    variant="outline"
                    className="border-cream/30 text-cream hover:border-cream/70 hover:bg-white/10"
                  >
                    <Link href="/#services">
                      <Gift className="h-4 w-4" />
                      Сертификаты
                    </Link>
                  </Button>
                </div>
                <p className="mt-4 text-[9px] uppercase tracking-[0.16em] text-cream/40">
                  Ближайшие окна — на этой неделе
                </p>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
