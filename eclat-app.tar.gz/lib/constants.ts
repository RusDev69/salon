export const BRAND = {
  name: "ÉCLAT",
  fullName: "Éclat Beauty Atelier",
  tagline: "Искусство быть собой",
  phone: "+7 (495) 120-38-08",
  phoneHref: "tel:+74951203808",
  address: "Москва, Пречистенка, 12",
  addressShort: "Пречистенка, 12",
  hours: "Ежедневно, 10:00–21:00",
  instagram: "https://instagram.com",
  telegram: "https://t.me",
  email: "hello@eclat.ru",
};

export const NAV_LINKS = [
  { href: "/#services", label: "Услуги" },
  { href: "/#masters", label: "Мастера" },
  { href: "/#philosophy", label: "О нас" },
  { href: "/#reviews", label: "Отзывы" },
  { href: "/#contacts", label: "Контакты" },
];

export const SERVICE_CATEGORIES = [
  { value: "ALL", label: "Все услуги" },
  { value: "HAIR", label: "Волосы" },
  { value: "NAILS", label: "Ногти" },
  { value: "SKIN", label: "Кожа" },
  { value: "MAKEUP", label: "Макияж" },
  { value: "BROWS", label: "Брови" },
] as const;

export type ServiceCategory = (typeof SERVICE_CATEGORIES)[number]["value"];

export const BOOKING_STATUSES = [
  { value: "PENDING", label: "Ожидает" },
  { value: "CONFIRMED", label: "Подтверждена" },
  { value: "COMPLETED", label: "Завершена" },
  { value: "CANCELLED", label: "Отменена" },
] as const;

export type BookingStatus = (typeof BOOKING_STATUSES)[number]["value"];

export const STATUS_STYLES: Record<
  BookingStatus,
  { label: string; className: string; dot: string }
> = {
  PENDING: {
    label: "Ожидает",
    className: "bg-amber-50 text-amber-800 border-amber-200/70",
    dot: "bg-amber-500",
  },
  CONFIRMED: {
    label: "Подтверждена",
    className: "bg-emerald-50 text-emerald-800 border-emerald-200/70",
    dot: "bg-emerald-500",
  },
  COMPLETED: {
    label: "Завершена",
    className: "bg-stone-100 text-stone-700 border-stone-200",
    dot: "bg-stone-500",
  },
  CANCELLED: {
    label: "Отменена",
    className: "bg-rose-50 text-rose-700 border-rose-200/80",
    dot: "bg-rose-400",
  },
};

export const MASTER_PHOTOS = [
  "/images/master-1.svg",
  "/images/master-2.svg",
  "/images/master-3.svg",
  "/images/master-4.svg",
];

export const TESTIMONIALS = [
  {
    name: "Анастасия Р.",
    service: "AirTouch · Алина",
    text: "Впервые вышла из салона без мысли «дома переделаю». Цвет живёт уже третий месяц, а волосы будто стали здоровее. Атмосфера — отдельная любовь.",
    rating: 5,
  },
  {
    name: "Ксения М.",
    service: "Ритуал для лица · Елена",
    text: "Тот самый случай, когда уход — это не процедура, а час тишины для себя. Кожа сияет, тело выдохнуло. Уже записана на следующий месяц.",
    rating: 5,
  },
  {
    name: "Дарья Л.",
    service: "Маникюр · София",
    text: "Идеальная форма, тончайшее покрытие и ни одного пузырька. София чувствует оттенок лучше, чем я сама. Хожу только сюда.",
    rating: 5,
  },
  {
    name: "Мария К.",
    service: "Брови · Мария",
    text: "Наконец нашла мастера, который не делает «модные» брови всем подряд. Форма подошла идеально, а взгляд стал мягче. Спасибо за деликатность.",
    rating: 5,
  },
] as const;
