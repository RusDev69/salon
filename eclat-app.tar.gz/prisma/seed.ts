import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { addDays } from "date-fns";
import { formatInTimeZone, fromZonedTime } from "date-fns-tz";
import "dotenv/config";

const prisma = new PrismaClient();
const TZ = "Europe/Moscow";

const today = formatInTimeZone(new Date(), TZ, "yyyy-MM-dd");
const tomorrow = formatInTimeZone(addDays(new Date(), 1), TZ, "yyyy-MM-dd");
const yesterday = formatInTimeZone(addDays(new Date(), -1), TZ, "yyyy-MM-dd");

function at(date: string, time: string) {
  return fromZonedTime(`${date}T${time}:00`, TZ);
}

function ref(seed: string) {
  return `ECL-${seed}`;
}

async function main() {
  await prisma.booking.deleteMany();
  await prisma.slotBlock.deleteMany();
  await prisma.masterSchedule.deleteMany();
  await prisma.masterService.deleteMany();
  await prisma.service.deleteMany();
  await prisma.master.deleteMany();

  const ownerPassword = await bcrypt.hash("Eclat2026!", 10);
  await prisma.user.upsert({
    where: { email: "owner@eclat.ru" },
    update: { passwordHash: ownerPassword, name: "Алиса Морозова", role: "OWNER" },
    create: {
      email: "owner@eclat.ru",
      name: "Алиса Морозова",
      passwordHash: ownerPassword,
      role: "OWNER",
    },
  });

  const servicesData = [
    {
      slug: "hair-styling",
      name: "Стрижка и укладка",
      description: "Стрижка по форме лица, мытьё, уход и укладка в авторской технике.",
      category: "HAIR",
      durationMin: 90,
      price: 6500,
      sortOrder: 1,
    },
    {
      slug: "airtouch",
      name: "Окрашивание AirTouch",
      description: "Мягкое растяжение цвета без резких границ. Включает тонирование и уход.",
      category: "HAIR",
      durationMin: 180,
      price: 14500,
      sortOrder: 2,
    },
    {
      slug: "hair-botox",
      name: "Ботокс для волос",
      description: "Глубокое восстановление, зеркальный блеск и гладкость на 3–4 месяца.",
      category: "HAIR",
      durationMin: 120,
      price: 9000,
      sortOrder: 3,
    },
    {
      slug: "manicure",
      name: "Маникюр + покрытие",
      description: "Аппаратный маникюр, укрепление и покрытие оттенком из сезонной палитры.",
      category: "NAILS",
      durationMin: 90,
      price: 4500,
      sortOrder: 4,
    },
    {
      slug: "pedicure",
      name: "SPA-педикюр",
      description: "Деликатный уход, тёплый парафин и покрытие стойким гель-лаком.",
      category: "NAILS",
      durationMin: 90,
      price: 5500,
      sortOrder: 5,
    },
    {
      slug: "facial-ritual",
      name: "Ритуал для лица Éclat",
      description: "Авторский уход: очищение, энзимная полировка, массаж и альгинатная маска.",
      category: "SKIN",
      durationMin: 75,
      price: 7800,
      sortOrder: 6,
    },
    {
      slug: "face-massage",
      name: "Скульптурный массаж лица",
      description: "Мягкая работа с лимфотоком и тонусом — эффект отдохнувшего лица.",
      category: "SKIN",
      durationMin: 60,
      price: 5200,
      sortOrder: 7,
    },
    {
      slug: "evening-makeup",
      name: "Вечерний макияж",
      description: "Сияющая кожа, выразительный взгляд и стойкость до самого утра.",
      category: "MAKEUP",
      durationMin: 60,
      price: 6000,
      sortOrder: 8,
    },
    {
      slug: "brows",
      name: "Архитектура бровей",
      description: "Форма по золотому сечению, коррекция и окрашивание в мягкий оттенок.",
      category: "BROWS",
      durationMin: 45,
      price: 3200,
      sortOrder: 9,
    },
  ];

  const services = await Promise.all(
    servicesData.map((data) => prisma.service.create({ data })),
  );
  const s = Object.fromEntries(services.map((service) => [service.slug, service]));

  const mastersData = [
    {
      slug: "alina-vetrova",
      name: "Алина Ветрова",
      specialty: "Колорист · стилист",
      bio: "9 лет создаёт цвет, который живёт вместе с вами: мягкие переходы, дорогой блеск и здоровье волос.",
      photoUrl: "/images/master-1.svg",
      rating: 5.0,
      reviewsCount: 112,
      experienceYears: 9,
      sortOrder: 1,
      serviceSlugs: ["hair-styling", "airtouch", "hair-botox"],
    },
    {
      slug: "sofia-lebedeva",
      name: "София Лебедева",
      specialty: "Nail-артист",
      bio: "Минималистичная эстетика, безупречная архитектура ногтя и оттенки, которые хочется носить.",
      photoUrl: "/images/master-2.svg",
      rating: 4.9,
      reviewsCount: 86,
      experienceYears: 7,
      sortOrder: 2,
      serviceSlugs: ["manicure", "pedicure"],
    },
    {
      slug: "elena-morozova",
      name: "Елена Морозова",
      specialty: "Косметолог-эстетист",
      bio: "Работает с кожей бережно и системно. Авторские ритуалы, после которых лицо будто отдохнуло месяц.",
      photoUrl: "/images/master-3.svg",
      rating: 5.0,
      reviewsCount: 143,
      experienceYears: 12,
      sortOrder: 3,
      serviceSlugs: ["facial-ritual", "face-massage"],
    },
    {
      slug: "maria-sokolova",
      name: "Мария Соколова",
      specialty: "Визажист · бровист",
      bio: "Подчёркивает природную архитектуру лица. Любит прозрачные текстуры, свет и точные линии.",
      photoUrl: "/images/master-4.svg",
      rating: 4.8,
      reviewsCount: 64,
      experienceYears: 5,
      sortOrder: 4,
      serviceSlugs: ["evening-makeup", "brows"],
    },
  ];

  const masters: Record<string, { id: string }> = {};
  for (const data of mastersData) {
    const { serviceSlugs, ...master } = data;
    const created = await prisma.master.create({
      data: {
        ...master,
        services: {
          create: serviceSlugs.map((slug) => ({ serviceId: s[slug].id })),
        },
      },
    });
    masters[data.slug] = created;
  }

  // Вторник–воскресенье, 10:00–21:00. Понедельник — выходной.
  await prisma.masterSchedule.createMany({
    data: Object.values(masters).flatMap((master) =>
      [2, 3, 4, 5, 6, 7].map((dayOfWeek) => ({
        masterId: master.id,
        dayOfWeek,
        startTime: new Date("1970-01-01T10:00:00.000Z"),
        endTime: new Date("1970-01-01T21:00:00.000Z"),
        isActive: true,
      })),
    ),
  });

  await prisma.booking.createMany({
    data: [
      {
        reference: ref("A-1041"),
        customerName: "Анна К.",
        customerPhone: "+7 (916) 204-18-41",
        customerEmail: "anna@example.com",
        notes: "Предпочтение — холодный блонд.",
        startsAt: at(today, "11:00"),
        endsAt: at(today, "14:00"),
        status: "CONFIRMED",
        serviceId: s["airtouch"].id,
        masterId: masters["alina-vetrova"].id,
      },
      {
        reference: ref("A-1042"),
        customerName: "Дарья С.",
        customerPhone: "+7 (925) 771-30-12",
        startsAt: at(today, "13:30"),
        endsAt: at(today, "15:00"),
        status: "PENDING",
        serviceId: s["manicure"].id,
        masterId: masters["sofia-lebedeva"].id,
      },
      {
        reference: ref("A-1043"),
        customerName: "Мария Л.",
        customerPhone: "+7 (903) 118-42-90",
        notes: "Чувствительная кожа.",
        startsAt: at(today, "16:00"),
        endsAt: at(today, "17:15"),
        status: "CONFIRMED",
        serviceId: s["facial-ritual"].id,
        masterId: masters["elena-morozova"].id,
      },
      {
        reference: ref("A-1044"),
        customerName: "Ольга В.",
        customerPhone: "+7 (926) 540-09-77",
        startsAt: at(today, "18:30"),
        endsAt: at(today, "19:30"),
        status: "PENDING",
        serviceId: s["evening-makeup"].id,
        masterId: masters["maria-sokolova"].id,
      },
      {
        reference: ref("A-1045"),
        customerName: "Ксения Р.",
        customerPhone: "+7 (915) 333-81-20",
        startsAt: at(tomorrow, "12:00"),
        endsAt: at(tomorrow, "13:30"),
        status: "CONFIRMED",
        serviceId: s["hair-styling"].id,
        masterId: masters["alina-vetrova"].id,
      },
      {
        reference: ref("A-1039"),
        customerName: "Ирина Т.",
        customerPhone: "+7 (977) 890-11-05",
        startsAt: at(yesterday, "15:00"),
        endsAt: at(yesterday, "16:30"),
        status: "COMPLETED",
        serviceId: s["pedicure"].id,
        masterId: masters["sofia-lebedeva"].id,
      },
    ],
  });

  await prisma.slotBlock.createMany({
    data: [
      {
        masterId: masters["alina-vetrova"].id,
        startsAt: at(today, "15:00"),
        endsAt: at(today, "17:00"),
        reason: "Личное время",
      },
      {
        masterId: masters["sofia-lebedeva"].id,
        startsAt: at(tomorrow, "16:00"),
        endsAt: at(tomorrow, "17:30"),
        reason: "Обучение",
      },
    ],
  });

  console.log("Seed complete");
  console.log("Owner login: owner@eclat.ru / Eclat2026!");
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
