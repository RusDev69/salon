-- ============================================================================
-- ÉCLAT — demo catalog for a fresh Supabase project.
--
-- Run after the migration:
--   supabase db reset          (local)
--   supabase db push           (remote)
--   psql "$DATABASE_URL" -f supabase/seed.sql
--
-- The owner account itself is created by Supabase Auth (Dashboard → Auth →
-- Users or the sign-up form). Promote it once:
--   update public.profiles set role = 'owner' where email = 'owner@eclat.ru';
-- ============================================================================

begin;

insert into public.services
  (slug, name, description, category, duration_minutes, price, is_active, sort_order)
values
  ('hair-styling', 'Стрижка и укладка',
   'Стрижка по форме лица, мытьё, уход и укладка в авторской технике.',
   'HAIR', 90, 6500, true, 1),
  ('airtouch', 'Окрашивание AirTouch',
   'Мягкое растяжение цвета без резких границ. Включает тонирование и уход.',
   'HAIR', 180, 14500, true, 2),
  ('hair-botox', 'Ботокс для волос',
   'Глубокое восстановление, зеркальный блеск и гладкость на 3–4 месяца.',
   'HAIR', 120, 9000, true, 3),
  ('manicure', 'Маникюр + покрытие',
   'Аппаратный маникюр, укрепление и покрытие оттенком из сезонной палитры.',
   'NAILS', 90, 4500, true, 4),
  ('pedicure', 'SPA-педикюр',
   'Деликатный уход, тёплый парафин и покрытие стойким гель-лаком.',
   'NAILS', 90, 5500, true, 5),
  ('facial-ritual', 'Ритуал для лица Éclat',
   'Авторский уход: очищение, энзимная полировка, массаж и альгинатная маска.',
   'SKIN', 75, 7800, true, 6),
  ('face-massage', 'Скульптурный массаж лица',
   'Мягкая работа с лимфотоком и тонусом — эффект отдохнувшего лица.',
   'SKIN', 60, 5200, true, 7),
  ('evening-makeup', 'Вечерний макияж',
   'Сияющая кожа, выразительный взгляд и стойкость до самого утра.',
   'MAKEUP', 60, 6000, true, 8),
  ('brows', 'Архитектура бровей',
   'Форма по золотому сечению, коррекция и окрашивание в мягкий оттенок.',
   'BROWS', 45, 3200, true, 9)
on conflict (slug) do update set
  name = excluded.name,
  description = excluded.description,
  category = excluded.category,
  duration_minutes = excluded.duration_minutes,
  price = excluded.price,
  is_active = excluded.is_active,
  sort_order = excluded.sort_order;

insert into public.masters
  (slug, name, specialization, bio, photo_url, rating, reviews_count,
   experience_years, is_active, sort_order)
values
  ('alina-vetrova', 'Алина Ветрова', 'Колорист · стилист',
   '9 лет создаёт цвет, который живёт вместе с вами: мягкие переходы, дорогой блеск и здоровье волос.',
   '/images/master-1.svg', 5.0, 112, 9, true, 1),
  ('sofia-lebedeva', 'София Лебедева', 'Nail-артист',
   'Минималистичная эстетика, безупречная архитектура ногтя и оттенки, которые хочется носить.',
   '/images/master-2.svg', 4.9, 86, 7, true, 2),
  ('elena-morozova', 'Елена Морозова', 'Косметолог-эстетист',
   'Работает с кожей бережно и системно. Авторские ритуалы, после которых лицо будто отдохнуло месяц.',
   '/images/master-3.svg', 5.0, 143, 12, true, 3),
  ('maria-sokolova', 'Мария Соколова', 'Визажист · бровист',
   'Подчёркивает природную архитектуру лица. Любит прозрачные текстуры, свет и точные линии.',
   '/images/master-4.svg', 4.8, 64, 5, true, 4)
on conflict (slug) do update set
  name = excluded.name,
  specialization = excluded.specialization,
  bio = excluded.bio,
  photo_url = excluded.photo_url,
  rating = excluded.rating,
  reviews_count = excluded.reviews_count,
  experience_years = excluded.experience_years,
  is_active = excluded.is_active,
  sort_order = excluded.sort_order;

-- Master ↔ service matrix
insert into public.master_services (master_id, service_id)
select m.id, s.id
from (values
  ('alina-vetrova', 'hair-styling'),
  ('alina-vetrova', 'airtouch'),
  ('alina-vetrova', 'hair-botox'),
  ('sofia-lebedeva', 'manicure'),
  ('sofia-lebedeva', 'pedicure'),
  ('elena-morozova', 'facial-ritual'),
  ('elena-morozova', 'face-massage'),
  ('maria-sokolova', 'evening-makeup'),
  ('maria-sokolova', 'brows')
) as pairs(master_slug, service_slug)
join public.masters m on m.slug = pairs.master_slug
join public.services s on s.slug = pairs.service_slug
on conflict do nothing;

-- Weekly availability: Tuesday–Sunday, 10:00–21:00 (Monday is a day off).
insert into public.master_schedules (master_id, day_of_week, start_time, end_time, is_active)
select m.id, day, time '10:00', time '21:00', true
from public.masters m
cross join generate_series(2, 7) as day
where m.is_active = true
on conflict (master_id, day_of_week, start_time) do update
set end_time = excluded.end_time, is_active = true;

-- Demo visits for the current shift. The booking trigger recalculates
-- end_time from services.duration_minutes, so the placeholder end is safe.
with demo(master_slug, service_slug, reference, customer_name, customer_phone,
          customer_email, notes, start_time, status) as (
  values
    ('alina-vetrova', 'airtouch', 'ECL-SEED01', 'Анна К.', '+7 (916) 204-18-41',
     'anna@example.com', 'Предпочтение — холодный блонд.',
     ((current_date + time '11:00') at time zone 'Europe/Moscow')::timestamptz, 'confirmed'::public.booking_status),
    ('sofia-lebedeva', 'manicure', 'ECL-SEED02', 'Дарья С.', '+7 (925) 771-30-12',
     null, null,
     ((current_date + time '13:30') at time zone 'Europe/Moscow')::timestamptz, 'pending'::public.booking_status),
    ('elena-morozova', 'facial-ritual', 'ECL-SEED03', 'Мария Л.', '+7 (903) 118-42-90',
     null, 'Чувствительная кожа.',
     ((current_date + time '16:00') at time zone 'Europe/Moscow')::timestamptz, 'confirmed'::public.booking_status),
    ('maria-sokolova', 'evening-makeup', 'ECL-SEED04', 'Ольга В.', '+7 (926) 540-09-77',
     null, null,
     ((current_date + time '18:30') at time zone 'Europe/Moscow')::timestamptz, 'pending'::public.booking_status)
)
insert into public.bookings
  (reference, master_id, service_id, customer_name, customer_phone, customer_email,
   notes, start_time, end_time, status)
select
  demo.reference, m.id, s.id, demo.customer_name, demo.customer_phone,
  demo.customer_email, demo.notes, demo.start_time,
  demo.start_time + interval '1 hour', demo.status
from demo
join public.masters m on m.slug = demo.master_slug
join public.services s on s.slug = demo.service_slug
on conflict (reference) do nothing;

-- A personal block, visible in the owner schedule grid.
insert into public.slot_blocks (master_id, start_time, end_time, reason)
select m.id,
       ((current_date + time '15:00') at time zone 'Europe/Moscow')::timestamptz,
       ((current_date + time '17:00') at time zone 'Europe/Moscow')::timestamptz,
       'Личное время'
from public.masters m
where m.slug = 'alina-vetrova'
on conflict (master_id, start_time) do nothing;

commit;
