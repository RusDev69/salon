import type { Config } from "tailwindcss";
import tailwindcssAnimate from "tailwindcss-animate";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}",
  ],
  theme: {
    container: {
      center: true,
      padding: { DEFAULT: "1.25rem", lg: "2rem" },
      screens: { "2xl": "1320px" },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        cream: "#F8F3EB",
        ivory: "#FDFBF7",
        sand: "#EDE2D3",
        /* Brand accent — dusty rose (#E8B4B8) */
        rose: {
          50: "#FCF5F4",
          100: "#F8E9E8",
          200: "#F1D6D8",
          300: "#EFCBCD",
          400: "#E8B4B8",
          500: "#C98B8B",
          600: "#A65F66",
          700: "#82474E",
          800: "#61343A",
          900: "#432327",
        },
        /* Brand accent — warm gold (#D4A373) */
        gold: {
          100: "#F7EFE5",
          200: "#EFDFCC",
          300: "#E4C9A9",
          400: "#DDB98F",
          500: "#D4A373",
          600: "#A97B50",
          700: "#855E3B",
          800: "#64462C",
          900: "#46311F",
        },
        espresso: "#2C2521",
        taupe: "#7F7671",
        warm: "#A8A29E",
      },
      fontFamily: {
        display: ["var(--font-display)", "Georgia", "serif"],
        sans: ["var(--font-sans)", "Segoe UI", "sans-serif"],
      },
      boxShadow: {
        /* Reference token from the design system */
        whisper: "0 8px 30px rgb(0 0 0 / 0.04)",
        soft: "0 18px 50px -24px rgba(70, 48, 40, 0.28)",
        lift: "0 30px 70px -30px rgba(70, 48, 40, 0.38)",
        glow: "0 0 0 1px rgba(255,255,255,.55), 0 24px 60px -28px rgba(120, 78, 70, .28)",
        inset: "inset 0 1px 0 rgba(255,255,255,.7)",
      },
      borderRadius: {
        "4xl": "2rem",
        "5xl": "2.75rem",
      },
      keyframes: {
        marquee: {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
        float: {
          "0%,100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-10px)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "200% 0" },
          "100%": { backgroundPosition: "-200% 0" },
        },
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(16px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
      },
      animation: {
        marquee: "marquee 32s linear infinite",
        float: "float 7s ease-in-out infinite",
        shimmer: "shimmer 3s linear infinite",
        "fade-up": "fade-up .7s ease forwards",
      },
    },
  },
  plugins: [tailwindcssAnimate],
};

export default config;
